@extends('layouts.app')
@section('content')
    <div class="row">
        @include('partials.sidebar')
         <div class="col-lg-9 col-md-12">
            <div class="row">
                <div class="col" >
                 
                   <div class="card " >
                    <div class="header">
                        <h2><strong>{{ __('Automatic deposit') }}</strong></h2>
                    </div>
                    <div class="body">
                     
                        <div class="row">
                            <div class="col">
                                <p>Using popular payment methods.</p>
                            </div>
                        </div>
                        <form action="{{route('auto_deposit_post', app()->getLocale())}}" method="post" enctype="multipart/form-data" >
                          {{csrf_field()}}
                          <div class="row">
                            <div class="col-sm-6">
                              <div class="form-group">
                                  <label>{{  __('Deposit Amount')  }}</label>
                                  <input type="text" class="form-control" required name="amount">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-sm-3">
                              <button type="submit" class="btn btn-primary">
                                {{__('Add Funds')}}
                              </button>
                            </div>
                          </div>
                        </form>
                        <!-- <div class="row">
                            <div class="col">
                                 
                                <a href="{{url('/')}}/{{app()->getLocale()}}/gatepay" class="btn btn-primary btn-round  btn-simple  m-l-10"> 
                                    {{__('Add Funds')}}
                                </a>
                            </div>
                        </div> -->
                    </div>
                  </div>
                </div>
            </div>  
             
            <div class="row">
                <div class="col" >
                   <div class="card bg-light" >
                    <div class="header" style="background-color:#ffffff;">
                        <h2><strong>{{ __('Select deposit method') }}</strong></h2>
                    </div>
                    <div class="body"style="background-color:#ffffff;">
                     
                      <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <form action="{{ route('save.mydeposits', app()->getLocale()) }}" method="POST" enctype="multipart/form-data">
                                    <meta name="csrf-token" content="{{ csrf_token() }}" />
                                    @csrf
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Amount</label>
                                                <input type="text" name="amount" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Payment Method</label>
                                                <select class="form-control deposit" name="deposit_method_id" required>
                                                    <option value="">--select--</option>
                                                    @if(!empty($depositMethod))
                                                    @foreach($depositMethod as $row)
                                                    <option value="{{$row->id}}">{{$row->name}}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                <small class="detail"></small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Payment Proof</label>
                                                <input type="file" name="transaction_receipt" class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-round bg-blue m-l-10">{{__('Submit')}}</button>
                                </form>            
                            </div>
                        
                        </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded',function(){
            $('body').on('change','.deposit',function(){
                let id  = $('body').find(this).find(':selected').val();
                let text = '';
                $.ajax({
                    url:"{{ route('save.mydeposits', app()->getLocale()) }}",
                    method:'POST',
                    datatype:'json',
                    data:{'id':id},
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success:function(response)
                    {
                        if(response.detail)
                        {
                            $('body').find('.detail').show(); 
                            $('body').find('.detail').text(response.detail);
                        }
                        if(response.detail == '')
                         {
                            $('body').find('.detail').hide();    
                        }
                    }
                })
            })
        })
    </script>
@endsection
